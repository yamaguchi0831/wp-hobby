<?php
/**
 * Static first-stage template generated from pages/page-privacy.html.
 *
 * @package BuyBuyComs_Hobby
 */
/*
Template Name: Privacy Policy
*/
?>
<?php get_header(); ?>

    <main id="main-content">
      <section class="hb__p-subpage-title" aria-label="利用規約">
        <div class="hb__l-container hb__p-subpage-title__inner">
          <h1 class="hb__p-subpage-title__heading">利用規約</h1>
        </div>
      </section>
      <div class="hb__l-container">
      <?php buybuycoms_hobby_breadcrumb(); ?>
      </div>

      <section class="hb__l-section hb-privacy__p-document">
        <article class="hb__l-container--sm hb-privacy__p-document__content">
          <h2 class="hb-privacy__p-document__title">買取申込利用規約</h2>
          <p class="hb-privacy__p-document__text">
            売買コムズ (以下、当店)
            は、個人情報の重要性を認識し、個人情報の適切な管理を行うことが当店の事業活動の基本であると共に、当店の社会的責務であると考えております。
          </p>
          <p class="hb-privacy__p-document__text">
            当店は、お客様に安心して当店ウェブページをご利用いただけるよう鋭意努力いたします。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            個人情報保護方針について
          </h3>
          <h3 class="hb-privacy__p-document__heading">
            個人情報の収集について
          </h3>
          <p class="hb-privacy__p-document__text">
            当店は当ウェブサイトを通じて、買取・ご質問の際にお客様個人を識別可能な情報を収集する場合がございます。
          </p>
          <p class="hb-privacy__p-document__text">
            個人情報の収集に際しましては、お客様のご意思を尊重し、予め収集目的をお客様に明示した上で、適法かつ公正な手段により、お客様に明示した目的の達成のためこれを超えない範囲で行います。
          </p>
          <p class="hb-privacy__p-document__text">
            当店では広告の効果測定のため、第三者の運営するツールから当サイトに訪れる前にクリックされている広告の情報（クリック日や広告掲載サイトなど）を取得し、お申込み情報と照合する場合がございます。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            個人情報の管理について
          </h3>
          <p class="hb-privacy__p-document__text">
            お客様から収集した個人情報は、当店ウェブサイト管理責任者が厳重に管理し、漏洩・流用・改ざん・紛失・破壊等の防止に適切な対策を講じます。
          </p>
          <p class="hb-privacy__p-document__text">
            また日々セキュリティの向上に努め、より安心してご利用いただけるよう配慮してまいります。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            個人情報の利用制限について
          </h3>
          <p class="hb-privacy__p-document__text">
            当店が収集いたしました個人情報は、お客様に明示した収集目的の達成に必要な範囲でのみ、お客様の権利に配慮して利用いたします。
          </p>
          <p class="hb-privacy__p-document__text">
            お客様に同意なく範囲を超えて情報を利用することはございません。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            個人情報の第三者への提供について
          </h3>
          <p class="hb-privacy__p-document__text">
            当店はお客様に提供いただきました個人情報を、第三者に対して開示いたしません。
          </p>
          <p class="hb-privacy__p-document__text">
            ただし、次のいずれかに該当する場合は、その限りではございません。
          </p>
          <p class="hb-privacy__p-document__text">
            当店からの事前の確認に対し、お客様からの同意があったとみなされる場合
          </p>
          <ul class="hb-privacy__p-document__list">
            <li>
              統計的なデータとして、お客様個人を特定できない状態に加工した場合
            </li>
            <li>行政機関より法的義務を伴う情報提出の要請を受けた場合</li>
            <li>法令に基づく場合</li>
            <li>
              お客様および公衆の生命、健康、財産などに重大な損害が発生するとされた場合
            </li>
          </ul>
          <h3 class="hb-privacy__p-document__heading">
            個人情報の開示・訂正・削除について
          </h3>
          <p class="hb-privacy__p-document__text">
            当店ではお客様自らの個人情報について、開示・訂正・削除の要請を受けた場合、その請求がお客様ご本人であると断定できた後、必要な対応を行います。
          </p>
          <p class="hb-privacy__p-document__text">
            またサービスの提供に必要な一定期間を経過後は適切な処理に基づき削除いたします。
          </p>
          <h3 class="hb-privacy__p-document__heading">アクセス履歴について</h3>
          <p class="hb-privacy__p-document__text">
            当店ではいつ、どこからアクセスしたかサーバ上にアクセス履歴(アクセスログ)として蓄積しております。これらのデータは当店ウェブサイトの快適にご利用いただくために利用する統計的データであり、IPアドレスと時間帯を収集するもので、お客様個人を特定できるものではございません。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            プライバシーポリシーの改善について
          </h3>
          <p class="hb-privacy__p-document__text">
            当店ではよりお客様に安心してウェブサイトをご利用いただくため、プライバシーポリシーを改定する場合がございます。改定後は新方針を適用いたします。改定にあたり個人情報を収集いたしました個々のお客様に通知することはございませんので、随時このページをご確認いただきますよう、お願い申し上げます。
          </p>
          <h3 class="hb-privacy__p-document__heading">お問い合わせについて</h3>
          <p class="hb-privacy__p-document__text">
            お客様の個人情報に関するお問い合わせについては、ウェブサイト設置のお問い合わせよりお送りください。
          </p>
          <h3 class="hb-privacy__p-document__heading">預かり期間について</h3>
          <p class="hb-privacy__p-document__text">
            査定通知メールの送信日より、7日間ご連絡・ご返信いただけない場合は査定金額にご満足いただけたとし、買取代金をお支払いした時点で、お品物の所有権は、ご利用者様から当店に移転いたします。
          </p>
          <p class="hb-privacy__p-document__text">
            ※以降の返送、返品はいたしませんのであらかじめご了承ください。
          </p>
          <p class="hb-privacy__p-document__text">
            本人確認等、当店に責のない事由により買取契約が成立せず、査定結果の通知日から30日が経過した場合、お客様は本商品の所有権を放棄したとみなし、当店はお客様の承諾を得ることなく、本商品の処分を行うことができるものとします。
          </p>
          <p class="hb-privacy__p-document__text">
            当店が返送を行う場合における本商品につき、お客様の長期不在など何らかの理由により返却が完了できなかった場合で且つ当店からの当該返却された日から7日が経過したものについては、お客様は本商品の所有権を放棄したとみなし、当店は何らお客様に対して負担を負うことなく任意に本商品を処分できるものとします。
          </p>
          <h3 class="hb-privacy__p-document__heading">返送について</h3>
          <p class="hb-privacy__p-document__text">
            買取依頼の物品について、査定結果にご納得いただけなかった場合は、返送を依頼することができます。
          </p>
          <p class="hb-privacy__p-document__text">
            以下の場合、返送は着払いとなります。
          </p>
          <ul class="hb-privacy__p-document__list">
            <li>買取基準額に満たない商品、または買取できないものの返送</li>
            <li>書類不備などお客様都合による返送</li>
            <li>査定合計5,000円未満時</li>
          </ul>
          <p class="hb-privacy__p-document__text">
            ご不明点がございましたら、お問い合わせフォームよりお問い合わせください。
          </p>
          <h3 class="hb-privacy__p-document__heading">連絡方法について</h3>
          <p class="hb-privacy__p-document__text">
            査定結果等の連絡はお客様がお申し込みの際等にご登録をいただいたパソコン・携帯電話へメールまたはお電話にてご連絡致します。
          </p>
          <p class="hb-privacy__p-document__text">
            当店が正しい方法にて連絡を取らせて頂いた時点で連絡をさせて頂いたものとみなします。
          </p>
          <p class="hb-privacy__p-document__text">
            (ドメイン指定受信の解除がされておらず着信できなかったなどの理由はお客様責任となりますのでご注意ください。)
          </p>
          <h2 class="hb-privacy__p-document__title">利用規約</h2>
          <p class="hb-privacy__p-document__text">
            売買コムズ（以下、「当店」といいます。）は、当店が運営する買取サイト（以下、「本サイト」といいます。）について、以下の通りの利用規約（以下、「本規約」といいます。）を定めるものといたします。
          </p>
          <p class="hb-privacy__p-document__text">
            本サイトを利用される方は、本規約を承諾したものとみなします。
          </p>
          <h2 class="hb-privacy__p-document__title">第1条 総則</h2>
          <h3 class="hb-privacy__p-document__heading">本規約の適用範囲</h3>
          <p class="hb-privacy__p-document__text">
            本規約は、利用者による本サイトの利用に関する一切について適用されます。
          </p>
          <p class="hb-privacy__p-document__text">
            利用者は本サイトを利用するにあたり、本規約を誠実に遵守するものといたします。
          </p>
          <h3 class="hb-privacy__p-document__heading">細則</h3>
          <p class="hb-privacy__p-document__text">
            当店は、本規約の他に特定のサービスの利用についてご利用ガイド等の細則（以下、「利用細則」をいいます。）を定めることができます。
          </p>
          <p class="hb-privacy__p-document__text">
            利用細則は本規約の一部を構成するものといたしますが、利用細則の定めと本規約の定めが異なる場合は、利用細則の定めが優先して適用されるものといたします。
          </p>
          <h2 class="hb-privacy__p-document__title">第2条 利用者</h2>
          <p class="hb-privacy__p-document__text">
            利用者本規約において「利用者」とは、本規約及び利用細則に従い、本サイトを利用される方を総称します。
          </p>
          <h3 class="hb-privacy__p-document__heading">利用制限</h3>
          <p class="hb-privacy__p-document__text">
            以下のいずれかに該当する方は、本サイトの利用することができないものといたします。
          </p>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>本規約に違反したことがある方</li>
            <li>当店への届出事項に、虚偽の事実を届け出ている事が判明した方</li>
            <li>
              過去に当店が提供する全てのサービス（本サイトを含む）に関して、禁止行為があった場合
            </li>
            <li>当店が、利用者として不適格と判断した場合</li>
            <li>本サイトは日本国外からのご利用はできません。</li>
          </ol>
          <h3 class="hb-privacy__p-document__heading">利用者禁止行為</h3>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>
              利用者は、以下の行為を一切行ってはならないものといたします。
            </li>
            <li>
              本サイト利用を行う際、虚偽の情報、第三者の情報、存在しない情報等を送信・登録する行為
            </li>
            <li>
              第三者または当店に迷惑、不利益もしくは損害を与える行為、またはそのおそれのある行為
            </li>
            <li>
              第三者または当店の著作権、プライバシーその他の権利を侵害する行為、またはそのおそれのある行為
            </li>
            <li>公序良俗に反する行為、もしくはそのおそれのある行為</li>
            <li>
              選挙活動、またはこれに類似する行為や、その他政治および宗教に関する行為
            </li>
            <li>
              利用者の営業活動および営利を目的として当店のサービスを利用する行為
            </li>
            <li>
              コンピュータウイルス等の有害なプログラムを、本サイトを通じてまたは本サイトに関連して使用し、もしくは提供する行為
            </li>
            <li>その他、当店が不適当と判断する行為</li>
          </ol>
          <h2 class="hb-privacy__p-document__title">第3条 個人情報の取扱い</h2>
          <p class="hb-privacy__p-document__text">
            個人情報の取扱いについては<a
              class="hb-privacy__p-document__link"
              href="#hb-privacy__title--privacy"
              >プライバシーポリシー</a
            >をご確認下さい。
          </p>
          <h3 class="hb-privacy__p-document__heading">個人情報の定義</h3>
          <p class="hb-privacy__p-document__text">
            「個人情報」とは、本サイトを通じて利用者から収集させていただく、氏名、住所、電話番号、メールアドレス等、利用者個人を識別できる情報（他の情報と容易に照合することができ、それによって当該個人を識別できるものを含む）を意味します。アクセスログ集計について本サイトでは、どのようなサービス等が利用者に好まれているかを判断するために、アクセスログの集計を行います。アクセスログは利用者のドメイン名やIPアドレス、使用されているブラウザの種類、アクセス日時などが含まれますが、アクセスログはあくまでも統計的データとして用いるものであり、利用者の個人情報と結びつけることはございません。
          </p>
          <h2 class="hb-privacy__p-document__title">第4条 著作権</h2>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>
              サービスを通じて提供されるコンテンツの知的財産権は、全て当店に専属的に帰属するものといたします。
            </li>
            <li>
              利用者から提供された企画提案内容、画像及びその派生物に関する著作権、特許権、意匠権等の知的財産権は当店に帰属するものといたします。
            </li>
            <li>
              目的の如何を問わず、当店のコンテンツの無断複製、無断転載その他無断二次利用行為等の国内及び国の著作権法及びその他の法令により禁止される行為が発見された場合には、当店は直ちに法的措置をとるものといたします。
            </li>
          </ol>
          <h2 class="hb-privacy__p-document__title">第5条 免責事項</h2>
          <p class="hb-privacy__p-document__text">
            当店は以下の場合に、一時的に本サイトが停止、中止又は変更されたとしても、利用者が直接的又は間接的に被った一切の損害、損失、不利益等について、いかなる責任も負わないものといたします。
          </p>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>システムトラブルが発生した場合</li>
            <li>火災、停電等によりサービスの提供ができないとき</li>
            <li>
              地震、噴火、洪水、台風、津波等の天災によりサービスの提供ができないとき
            </li>
            <li>その他、当店が必要と判断した場合</li>
          </ol>
          <p class="hb-privacy__p-document__text">
            人為的なミスにより、サービス上の価格が実際に買取価格と異なる場合や非常識な価格での表示が生じた場合は、民法95条の「錯誤に基づく契約無効」に基づき、お申込頂いた契約については不成立とさせて頂きます。
          </p>
          <h2 class="hb-privacy__p-document__title">第6条 準拠法</h2>
          <p class="hb-privacy__p-document__text">
            本規約の成立、効力、履行および解釈に関しては、日本法が適用されるものといたします。
          </p>
          <h2 class="hb-privacy__p-document__title">第7条 合意管轄裁判所</h2>
          <p class="hb-privacy__p-document__text">
            本規約に関連して利用者と当店との間に争いが生じた場合は、利用者と当店との間で誠意をもって協議し、解決するものといたします。
          </p>
          <h2 class="hb-privacy__p-document__title">第8条 規約の変更</h2>
          <p class="hb-privacy__p-document__text">
            当店は、利用者の事前の承諾なしに任意に、本規約を変更できるものといたします。
          </p>
          <p class="hb-privacy__p-document__text">
            サービス上での掲載又はメール等の当店が適当と判断する方法で利用者に告知又は通知することにより、変更できるものといたします。
          </p>
          <p class="hb-privacy__p-document__text">令和8年5月1日制定実施</p>
          <h2
            id="hb-privacy__title--privacy"
            class="hb-privacy__p-document__title"
          >
            プライバシーポリシー
          </h2>
          <p class="hb-privacy__p-document__text">
            売買コムズでは、以下のとおり個人情報に対する保護方針を定めることで、個人情報保護の仕組みを構築し、全ての従業員に個人情報に対しての認識と取組みを徹底させ、個人情報の保護を推進致します。
          </p>
          <h3 class="hb-privacy__p-document__heading">１．個人情報の管理</h3>
          <p class="hb-privacy__p-document__text">
            売買コムズは、お客さまの個人情報(メールアドレスや電話番号等)を不正アクセス・紛失・漏洩などを防止するため、セキュリティ対策を徹底して個人情報の管理を行ないます。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            ２．個人情報の利用目的
          </h3>
          <p class="hb-privacy__p-document__text">
            お客さまからお預かりした個人情報は下記の目的で利用致します。
          </p>
          <ul class="hb-privacy__p-document__list">
            <li>
              お客様宅への商品買取、ご連絡、本人確認など売買コムズのサービス提供のため
            </li>
            <li>
              お客様からのお問い合わせやアフターサービスに関連するご連絡のため
            </li>
            <li>売買コムズ内でのマーケティング、及びサービスの改善のため</li>
            <li>e-mail、ダイレクトメールなどの販促のため</li>
            <li>広告および広告効果測定のため</li>
            <li>その他、業務上で必要な連絡のため</li>
          </ul>
          <h3 class="hb-privacy__p-document__heading">３．個人情報の提供</h3>
          <p class="hb-privacy__p-document__text">
            当社は、よりお客さまに関連性の強い広告を配信するため、広告配信、効果測定、分析等を行なうために、以下のとおり広告配信事業者に個人データを提供することがあります。
          </p>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>
              提供先の広告配信事業者：以下を含みます（リストは随時更新します。）
            </li>
          </ol>
          <p class="hb-privacy__p-document__text">Meta Platforms, Inc</p>
          <p class="hb-privacy__p-document__text">Google LLC</p>
          <p class="hb-privacy__p-document__text">LINEヤフー株式会社</p>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>提供する個人データ：ハッシュ化したメールアドレス等</li>
          </ol>
          <p class="hb-privacy__p-document__text">
            （当社が自ら取得したものであって、元のメールアドレス等に戻せない形式に加工したものです。）
          </p>
          <p class="hb-privacy__p-document__text">
            上記のほか、当社は、次に掲げる場合を除き、本人の同意を得ることなく個人データを第三者へ提供しません。
          </p>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>法令に基づく場合</li>
            <li>
              人の生命、身体または財産の保護のために必要がある場合であって、本人の同意を得ることが困難であると判断した場合
            </li>
            <li>
              公衆衛生の向上または児童の健全な育成の推進のために特に必要がある場合であって、本人の同意を得ることが困難であると判断した場合
            </li>
            <li>
              国の機関若しくは地方公共団体またはその委託を受けた者が法令の定める事務を遂行することに対して協力する必要がある場合であって、本人の同意を得ることによって当該事務の遂行に支障を及ぼす恐れがあると判断した場合
            </li>
            <li>
              出張買取、宅配買取などのサービスを行うため、第三者の運送業者をご利用する場合
            </li>
          </ol>
          <h3 class="hb-privacy__p-document__heading">
            ４．第三者による情報取得に関する免責事項
          </h3>
          <ol
            class="hb-privacy__p-document__list hb-privacy__p-document__list--ordered"
          >
            <li>
              当社のサービスを利用するために必要な識別情報（メールアドレスおよび電話番号等）を、ご本人以外が何らかの方法により取得した場合
            </li>
            <li>当社に故意または過失がない場合</li>
          </ol>
          <h3 class="hb-privacy__p-document__heading">
            ５．個人情報の安全対策
          </h3>
          <p class="hb-privacy__p-document__text">
            売買コムズでは、お客様の個人情報に対して注意を払い、厳重に管理しております。
          </p>
          <p class="hb-privacy__p-document__text">
            また個人情報の紛失や外部流出を防止するために、しっかりとセキュリティ対策を実施しております。
          </p>
          <h3 class="hb-privacy__p-document__heading">６．ご本人の照会</h3>
          <p class="hb-privacy__p-document__text">
            お客さまがご本人の個人情報の照会・修正・削除などをご希望される場合には、ご本人であることを確認の上、対応させていただきます。
          </p>
          <h3 class="hb-privacy__p-document__heading">
            ７．法令、規範の遵守と見直し
          </h3>
          <p class="hb-privacy__p-document__text">
            売買コムズは、保有する個人情報に関して適用される日本の法令、その他規範を遵守するとともに、本ポリシーの内容を適宜見直し、その改善に努めます。
          </p>
          <h3 class="hb-privacy__p-document__heading">■クッキーに関して</h3>
          <h3 class="hb-privacy__p-document__heading">
            １．クッキー(Cookie)とは
          </h3>
          <p class="hb-privacy__p-document__text">
            クッキーとは、ブラウザ上でお客様のコンピューターを認識するために記憶されるファイルの事です。
          </p>
          <p class="hb-privacy__p-document__text">
            クッキーを用いることでお客様ごとに専用のページを表示させることが可能になったりとサイト内で快適なサービスを受けるための便利なものです。
          </p>
          <p class="hb-privacy__p-document__text">
            クッキーには個人情報を保存することはありません。
          </p>
          <p class="hb-privacy__p-document__text">
            ※お客様自身でブラウザの設定変更により、この機能を無効化する事ができます。
          </p>
          <p class="hb-privacy__p-document__text">
            売買コムズでは、下記の目的のためクッキーを利用しております。
          </p>
          <ul class="hb-privacy__p-document__list">
            <li>売買コムズのサービス改善のため</li>
            <li>第三者が提供する広告サービスを利用して広告配信を行うため</li>
          </ul>
          <p class="hb-privacy__p-document__text">
            ※第三者の提供による広告サービスをオプトアウト(無効化)したい場合は、各社のサイトにアクセスして無効化の手順に従って設定して下さい。
          </p>
          <p class="hb-privacy__p-document__text">グーグル株式会社</p>
          <p class="hb-privacy__p-document__text">
            <a
              class="hb-privacy__p-document__link"
              href="https://support.google.com/ads/answer/2662922?hl=ja"
              target="_blank"
              rel="noopener"
              >https://support.google.com/ads/answer/2662922?hl=ja</a
            >
          </p>
          <p class="hb-privacy__p-document__text">ヤフー株式会社</p>
          <p class="hb-privacy__p-document__text">
            <a
              class="hb-privacy__p-document__link"
              href="https://btoptout.yahoo.co.jp/optout/index.html"
              target="_blank"
              rel="noopener"
              >https://btoptout.yahoo.co.jp/optout/index.html</a
            >
          </p>
          <p class="hb-privacy__p-document__text">令和8年5月1日制定実施</p>
        </article>
      </section>
    </main>

    <?php get_template_part( 'template-parts/common/footer-cta' ); ?>
    <?php get_footer(); ?>
