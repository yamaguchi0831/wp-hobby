<?php
/**
 * Static first-stage template part: footer-cta.
 *
 * @package BuyBuyComs_Hobby
 */
?>
<section class="hb__p-footer-cta" id="cta" data-screen-label="13 CTA">
  <div class="hb__p-footer-cta__bg" aria-hidden="true"></div>
  <div class="hb__l-container hb__p-footer-cta__inner">
    <h2 class="hb__p-footer-cta__title">
      今すぐ<span class="hb__p-footer-cta__title-accent">無料</span>で査定を申し込む
    </h2>
    <div class="hb__p-footer-cta__title-deco" aria-hidden="true">
      <span class="hb__p-footer-cta__title-line"></span>
      <img src="<?php echo esc_url( get_theme_file_uri( '/images/icon/cta-ican03.svg' ) ); ?>" alt="" />
      <span class="hb__p-footer-cta__title-line"></span>
    </div>
    <p class="hb__p-footer-cta__lead">
      24時間受付中。査定・送料0円。
    </p>

    <div class="hb__p-footer-cta__channels">
      <a
        href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
        class="hb__p-footer-cta__ch hb__p-footer-cta__ch--form"
      >
        <span class="hb__p-footer-cta__icon">
          <img src="<?php echo esc_url( get_theme_file_uri( '/images/icon/cta-ican01.svg' ) ); ?>" alt="" />
        </span>
        <span class="hb__p-footer-cta__content">
          <span class="hb__p-footer-cta__heading">買取を依頼する</span>
          <span class="hb__p-footer-cta__text"
            >買取方法は3種類！<br />24時間受付中！</span
          >
        </span>
        <span class="hb__p-footer-cta__button">
          <span class="hb__p-footer-cta__button-text"
            >無料査定を<span class="hb__p-footer-cta__pc-break"><br /></span
            >申し込む</span
          >
          <span class="hb__p-footer-cta__arrow" aria-hidden="true"></span>
        </span>
      </a>

      <a href="<?php echo esc_url( 'https://line.me/R/ti/p/@081xadbs' ); ?>" class="hb__p-footer-cta__ch hb__p-footer-cta__ch--line">
        <span class="hb__p-footer-cta__icon">
          <img src="<?php echo esc_url( get_theme_file_uri( '/images/icon/cta-ican02.svg' ) ); ?>" alt="" />
        </span>
        <span class="hb__p-footer-cta__content">
          <span class="hb__p-footer-cta__heading">LINEで写真査定する</span>
          <span class="hb__p-footer-cta__text"
            >写真を撮って送るだけ！<br />24時間受付中！</span
          >
        </span>
        <span class="hb__p-footer-cta__button">
          <span class="hb__p-footer-cta__button-text"
            >LINEで<span class="hb__p-footer-cta__pc-break"><br /></span
            >査定する</span
          >
          <span class="hb__p-footer-cta__arrow" aria-hidden="true"></span>
        </span>
      </a>
    </div>
  </div>
</section>
