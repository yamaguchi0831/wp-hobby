<?php
/**
 * Static first-stage template part: purchase-cases.
 *
 * @package BuyBuyComs_Hobby
 */
?>
<div class="hb__p-cases-grid">
  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=120+gunpla+kits"
      alt="ガンプラまとめ売り"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">プラモデル / まとめ売り</span>
      <h3 class="hb__p-cases-title">ガンプラRG・MG 約120点</h3>
      <p class="hb__p-cases-text">
        押し入れ整理。未組立中心、外箱コンディション良好。<br />
        2026/7/27 千葉県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 380,000 〜 482,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=scale+figures"
      alt="スケールフィギュア"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">フィギュア / コレクション引退</span>
      <h3 class="hb__p-cases-title">スケールフィギュア 86体</h3>
      <p class="hb__p-cases-text">
        コレクション引退。グッスマ・アルター・コトブキヤなど。<br />
        2026/7/27 東京都で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 215,000 〜 268,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=retro+famicom"
      alt="ファミコン"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">レトロゲーム / 遺品整理</span>
      <h3 class="hb__p-cases-title">ファミコン本体＋ソフト 240本</h3>
      <p class="hb__p-cases-text">
        遺品整理。箱・説明書付き多数、レア作品含む。<br />
        2026/7/27 神奈川県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 142,000 〜 188,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=pokemon+cards"
      alt="ポケモンカード"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">トレカ / まとめ売り</span>
      <h3 class="hb__p-cases-title">ポケモンカード 旧裏〜SV 約3,000枚</h3>
      <p class="hb__p-cases-text">
        趣味じまい。PSA鑑定品含む。<br />
        2026/7/27 大阪府で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 96,000 〜 124,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=henshin+belts"
      alt="変身ベルト"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">特撮 / コレクション</span>
      <h3 class="hb__p-cases-title">仮面ライダー変身ベルト 一式</h3>
      <p class="hb__p-cases-text">
        引っ越し前整理。DX歴代ベルト＋関連グッズ。<br />
        2026/7/27 埼玉県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 58,000 〜 76,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=chogokin"
      alt="超合金"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">超合金 / コレクション</span>
      <h3 class="hb__p-cases-title">超合金魂・DX超合金 38点</h3>
      <p class="hb__p-cases-text">
        生前整理。年代物・限定品を含む。<br />
        2026/7/27 愛知県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 168,000 〜 210,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=game+consoles"
      alt="ゲーム機まとめ売り"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">ゲーム機 / まとめ売り</span>
      <h3 class="hb__p-cases-title">Switch・PS5周辺機器 42点</h3>
      <p class="hb__p-cases-text">
        買い替え整理。本体・コントローラー・限定ソフト含む。<br />
        2026/7/27 福岡県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 112,000 〜 146,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>

  <article class="hb__p-cases-card">
    <img
      class="hb__p-cases-image"
      src="https://placehold.co/400x300/eef3ee/5f6f66?text=anime+goods"
      alt="アニメグッズまとめ売り"
      width="400"
      height="300"
    />
    <div class="hb__p-cases-body">
      <span class="hb__p-cases-category">アニメグッズ / 大量整理</span>
      <h3 class="hb__p-cases-title">缶バッジ・アクスタ 約650点</h3>
      <p class="hb__p-cases-text">
        推し活整理。未開封品・イベント限定品を含む。<br />
        2026/7/27 兵庫県で買取
      </p>
      <div class="hb__p-cases-foot">
        <span class="hb__p-cases-price">¥ 74,000 〜 98,000</span>
        <a class="hb__c-btn hb__c-btn--primary hb__p-cases-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
          >査定を申し込む</a
        >
      </div>
    </div>
  </article>
</div>
