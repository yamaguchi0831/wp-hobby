<?php
/**
 * Static first-stage template part: flow-tab.
 *
 * @package BuyBuyComs_Hobby
 */
?>
<div
            class="hb__p-flow-tabs"
            role="tablist"
            aria-label="買取方法"
          >
            <button
              class="hb__p-flow-tab hb__is-active"
              id="flow-tab-takuhai"
              role="tab"
              aria-selected="true"
              aria-controls="flow-panel-takuhai"
              type="button"
              data-flow-tab="takuhai"
            >
              宅配買取
            </button>
            <button
              class="hb__p-flow-tab"
              id="flow-tab-shuccho"
              role="tab"
              aria-selected="false"
              aria-controls="flow-panel-shuccho"
              type="button"
              data-flow-tab="shuccho"
            >
              出張買取
            </button>
            <button
              class="hb__p-flow-tab"
              id="flow-tab-store"
              role="tab"
              aria-selected="false"
              aria-controls="flow-panel-store"
              type="button"
              data-flow-tab="store"
            >
              店頭買取
            </button>
          </div>

          <div class="hb__p-flow-panels">
            <div
              class="hb__p-flow-pane"
              id="flow-panel-takuhai"
              role="tabpanel"
              aria-labelledby="flow-tab-takuhai"
              data-flow-panel="takuhai"
            >
              <div class="hb__p-flow-detail-head">
                <h3 class="hb__p-flow-detail-title">宅配買取の流れ</h3>
                <p class="hb__p-flow-detail-lead">
                  箱にまとめて送るだけ。全国どこからでも手数料無料でご利用いただけます。
                </p>
              </div>
              <div class="hb__p-flow-steps">
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/takuhai01.webp' ) ); ?>"
                      alt="梱包する箱のイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">発送する</h4>
                  <p class="hb__p-flow-step-text">
                    売りたいホビーを箱にまとめて着払いで送るだけ。箱がない場合は買取キットを無料プレゼントします。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/takuhai02.webp' ) ); ?>"
                      alt="査定のイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">査定</h4>
                  <p class="hb__p-flow-step-text">
                    専門スタッフがしっかりと査定を行い、査定額をご案内します。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/takuhai03.webp' ) ); ?>"
                      alt="お支払いのイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">お支払い</h4>
                  <p class="hb__p-flow-step-text">
                    査定額にご納得いただけましたら、指定口座へお振込みします。
                  </p>
                </article>
              </div>
              <div class="hb__p-flow-action">
                <a
                  class="hb__c-btn hb__c-btn--primary hb__c-btn--lg hb__p-flow-button"
                  href="<?php echo esc_url( add_query_arg( 'type', 'takuhai', home_url( '/contact/' ) ) ); ?>"
                >
                  宅配買取を依頼する
                </a>
              </div>
            </div>

            <div
              class="hb__p-flow-pane"
              id="flow-panel-shuccho"
              role="tabpanel"
              aria-labelledby="flow-tab-shuccho"
              data-flow-panel="shuccho"
              hidden
            >
              <div class="hb__p-flow-detail-head">
                <h3 class="hb__p-flow-detail-title">出張買取の流れ</h3>
                <p class="hb__p-flow-detail-lead">
                  大量のコレクションも運ばずにOK。専門スタッフがご自宅へ伺います。
                </p>
              </div>
              <div class="hb__p-flow-steps">
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/shucchou01.webp' ) ); ?>"
                      alt="相談するイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">日程調整をする</h4>
                  <p class="hb__p-flow-step-text">
                    内容や出張希望日時を専用フォームよりお知らせください。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/shucchou02.webp' ) ); ?>"
                      alt="出張査定のイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">出張査定</h4>
                  <p class="hb__p-flow-step-text">
                    専門スタッフがご自宅へ伺い丁寧に査定をいたします。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/shucchou03.webp' ) ); ?>"
                      alt="お支払いと引渡しのイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">お支払い＆引渡し</h4>
                  <p class="hb__p-flow-step-text">
                    査定額にご納得いただけましたらその場でお支払いし、商品をお引き取りいたします。
                  </p>
                </article>
              </div>
              <div class="hb__p-flow-action">
                <a
                  class="hb__c-btn hb__c-btn--primary hb__c-btn--lg hb__p-flow-button"
                  href="<?php echo esc_url( add_query_arg( 'type', 'shuccho', home_url( '/contact/' ) ) ); ?>"
                >
                  出張買取を依頼する
                </a>
              </div>
            </div>

            <div
              class="hb__p-flow-pane"
              id="flow-panel-store"
              role="tabpanel"
              aria-labelledby="flow-tab-store"
              data-flow-panel="store"
              hidden
            >
              <div class="hb__p-flow-detail-head">
                <h3 class="hb__p-flow-detail-title">店頭買取の流れ</h3>
                <p class="hb__p-flow-detail-lead">
                  お近くの方は店頭持ち込みも便利。少量から大量までご相談いただけます。
                </p>
              </div>
              <div class="hb__p-flow-steps">
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/tentou01.webp' ) ); ?>"
                      alt="持ち込み準備のイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">日程調整をする</h4>
                  <p class="hb__p-flow-step-text">
                    内容や持込希望日時を専用フォームよりお知らせください。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/tentou02.webp' ) ); ?>"
                      alt="店舗へ持ち込むイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">店舗へ持ち込む</h4>
                  <p class="hb__p-flow-step-text">
                    少量から大量まで、専門スタッフが丁寧に査定をいたします。
                  </p>
                </article>
                <article class="hb__p-flow-step">
                  <figure class="hb__p-flow-step-image">
                    <img
                      src="<?php echo esc_url( get_theme_file_uri( '/images/tentou03.webp' ) ); ?>"
                      alt="お支払いと引渡しのイメージ"
                    />
                  </figure>
                  <h4 class="hb__p-flow-step-title">お支払い＆引渡し</h4>
                  <p class="hb__p-flow-step-text">
                    査定額にご納得いただけましたらその場でお支払いし、商品をお引き取りいたします。
                  </p>
                </article>
              </div>
              <div class="hb__p-flow-action">
                <a
                  class="hb__c-btn hb__c-btn--primary hb__c-btn--lg hb__p-flow-button"
                  href="<?php echo esc_url( add_query_arg( 'type', 'mochikomi', home_url( '/contact/' ) ) ); ?>"
                >
                  店頭買取を依頼する
                </a>
              </div>
            </div>
          </div>
